// Запускает код сайта в песочнице Node с имитацией браузера (без реального DOM).
const vm = require('vm');
const fs = require('fs');

module.exports = function load(htmlPath) {
  const html = fs.readFileSync(htmlPath, 'utf8');
  const script = html.match(/<script>([\s\S]*)<\/script>/)[1]
    .replace(/loadDB\(\);\s*loadSession\(\);\s*render\(\);\s*$/, ''); // стартуем вручную

  const store = {}, els = {};
  const el = id => els[id] || (els[id] = {
    id, value: '', innerHTML: '', textContent: '', style: {}, dataset: {},
    classList: { add() {}, remove() {}, toggle() {} }, addEventListener() {},
    scrollTo() {}, scrollBy() {}, querySelector: () => null, querySelectorAll: () => [],
  });
  const sandbox = {
    console, crypto: require('crypto').webcrypto, TextEncoder, setTimeout, clearTimeout,
    requestAnimationFrame: fn => fn(), getComputedStyle: () => ({ gap: '0' }),
    localStorage: { getItem: k => (k in store ? store[k] : null), setItem: (k, v) => { store[k] = String(v); }, removeItem: k => { delete store[k]; } },
    document: { getElementById: el, querySelector: () => null, querySelectorAll: () => [], addEventListener() {}, body: { classList: { add() {}, remove() {}, toggle() {} } } },
    window: { scrollTo() {}, innerWidth: 1200, addEventListener() {} },
    navigator: {}, location: { reload() {} },
  };
  vm.createContext(sandbox);
  vm.runInContext(script, sandbox);
  const run = code => vm.runInContext(code, sandbox);
  run('loadDB(); loadSession();');
  return { run, els, store, el };
};
