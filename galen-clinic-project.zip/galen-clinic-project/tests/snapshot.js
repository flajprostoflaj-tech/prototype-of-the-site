// Снимок HTML всех экранов в разных ролях.
//   node tests/snapshot.js <site.html> <out.json>
// Сравнить два снимка: cmp a.json b.json
const fs = require('fs');
const load = require('./harness');
const [,, htmlPath, outPath] = process.argv;
const { run, els } = load(htmlPath);

// фиксируем даты, чтобы снимок не зависел от дня запуска
run('buildNext14Days = () => Array.from({length:14},(_,i)=>({iso:"2030-01-"+String(i+1).padStart(2,"0"),dow:"пн",num:i+1}))');
run(`DB.users.push({id:'u1',name:'Тест Клиент',phone:'+70000000000',email:'t@t.ru',passwordHash:'x',linked:{}});
     DB.appointments.push({id:'a1',userId:'u1',doctorId:'d1',serviceName:'Прием',price:100,catId:'gynecology',date:'2030-01-05',time:'10:00',status:'upcoming'});`);

const sessions = {
  guest: 'SESSION=null',
  client: 'SESSION={role:"client",userId:"u1"}',
  doctor: 'SESSION={role:"doctor",doctorId:"d1"}',
  admin: 'SESSION={role:"admin",editMode:false}',
};
const routes = [
  ['home'], ['services'], ['doctors'], ['doctors', { id: 'd2' }], ['forpatients'], ['contacts'],
  ['category', 'gynecology'], ['category', 'neurology'], ['category', 'uzi'],
  ['doctorServices', { doctorId: 'd1', catId: 'gynecology' }],
  ['booking', { catId: 'neurology', serviceId: 'neurology-svc-0' }],
  ['booking', { catId: 'gynecology', serviceId: 'gynecology-svc-3', doctorId: 'd4' }],
  ['profile'], ['doctorpanel'], ['adminpanel'],
];
const tabs = {
  profile: ['appointments', 'account', 'linked'].map(t => `profileTab="${t}"`),
  doctorpanel: ['schedule', 'workdays', 'block'].map(t => `doctorPanelTab="${t}"`),
  adminpanel: ['prices', 'categories', 'doctors', 'logins', 'service'].map(t => `adminTab="${t}"`),
};
const out = {};
for (const [role, setup] of Object.entries(sessions)) {
  for (const [view, param] of routes) {
    for (const tab of tabs[view] || [null]) {
      run(setup);
      if (tab) run(tab);
      const params = typeof param === 'object' ? param : { p: param };
      run(`ROUTE={view:${JSON.stringify(view)},params:${JSON.stringify(params)}}; bookingState={catId:null,serviceId:null,doctorId:null,date:null,time:null}; render();`);
      out[`${role}|${view}|${JSON.stringify(param || '')}|${tab || ''}`] = [els.app.innerHTML, els.authArea.innerHTML, els.navLinks.innerHTML];
    }
  }
}
run('SESSION=null; renderSheet()');
out.sheet = els.sheet.innerHTML;
fs.writeFileSync(outPath, JSON.stringify(out, null, 1));
console.log('снимков:', Object.keys(out).length);
