// Регрессионная проверка: собирает сайт, снимает HTML всех экранов и сравнивает с эталоном.
//   node tests/check.js            — сравнить
//   node tests/check.js --update   — принять текущее состояние как новый эталон
// Если вы намеренно меняли вёрстку, запустите с --update и посмотрите git diff эталона.
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const baselinePath = path.join(__dirname, 'baseline.json');
const tmp = path.join(__dirname, '.current.json');

execFileSync('node', [path.join(root, 'build.js')], { stdio: 'inherit' });
execFileSync('node', [path.join(__dirname, 'snapshot.js'), path.join(root, 'dist/galen-clinic.html'), tmp], { stdio: 'inherit' });

if (process.argv.includes('--update')) {
  fs.copyFileSync(tmp, baselinePath); fs.unlinkSync(tmp);
  console.log('эталон обновлён'); process.exit(0);
}
const base = JSON.parse(fs.readFileSync(baselinePath, 'utf8'));
const cur = JSON.parse(fs.readFileSync(tmp, 'utf8'));
fs.unlinkSync(tmp);
const changed = Object.keys({ ...base, ...cur }).filter(k => JSON.stringify(base[k]) !== JSON.stringify(cur[k]));
if (changed.length) {
  console.log(`ИЗМЕНИЛАСЬ отрисовка у ${changed.length} из ${Object.keys(base).length} экранов:`);
  changed.slice(0, 15).forEach(k => console.log('  -', k));
  console.log('Если это ожидаемо: node tests/check.js --update');
  process.exit(1);
}
console.log(`экраны не изменились (${Object.keys(base).length})`);
