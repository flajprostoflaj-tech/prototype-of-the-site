// Проверка сценариев: вход, запись, правки админа.  node tests/flows.js <site.html>
const load = require('./harness');
const assert = require('assert');
const { run, el } = load(process.argv[2]);
let passed = 0;
const test = async (name, fn) => { try { await fn(); passed++; console.log('  ок  ', name); } catch (e) { console.log('  FAIL', name, '\n      ', e.message); process.exitCode = 1; } };
const val = (id, v) => { el(id).value = v; };

(async () => {
  await test('склонение стажа', () => {
    const f = n => run(`yearsLabel(${n})`);
    assert.deepEqual([1, 2, 5, 11, 21, 22, 25].map(f), ['1 год', '2 года', '5 лет', '11 лет', '21 год', '22 года', '25 лет']);
  });

  await test('админ входит по своему паролю', async () => {
    val('staffPwd', 'mr.bobr_228336885880055530_eshe_ya_gofren');
    await run('doStaffLogin()');
    assert.equal(run('currentUser().role'), 'admin');
  });

  await test('админ задаёт пароль врачу, врач входит (role = doctor, должность отдельно)', async () => {
    val('newDoctorPwd', 'qwerty');
    await run("confirmDoctorPassword('d1')");
    run('SESSION=null; saveSession()');
    val('staffPwd', 'qwerty');
    await run('doStaffLogin()');
    assert.equal(run('currentUser().role'), 'doctor');
    assert.equal(run('currentUser().jobTitle'), 'Врач акушер-гинеколог');
  });

  await test('неверный пароль сотрудника не пускает', async () => {
    run('SESSION=null; saveSession()');
    val('staffPwd', 'wrong');
    await run('doStaffLogin()');
    assert.equal(run('SESSION'), null);
  });

  await test('регистрация и вход клиента', async () => {
    val('regName', 'Иван'); val('regPhone', '+79990001122'); val('regEmail', ''); val('regPwd', 'secret1');
    await run('doRegister()');
    assert.equal(run('currentUser().role'), 'client');
    run('SESSION=null; saveSession()');
    val('loginId', '+79990001122'); val('loginPwd', 'secret1');
    await run('doLogin()');
    assert.equal(run('currentUser().name'), 'Иван');
  });

  await test('запись на приём создаётся и занимает слот', () => {
    run(`bookingState={catId:'neurology',serviceId:'neurology-svc-0',doctorId:'d2',date:'2030-02-02',time:'12:00'}; confirmBooking()`);
    assert.equal(run('DB.appointments.length'), 1);
    assert.equal(run("isBookedByAppt('d2','2030-02-02','12:00')"), true);
  });

  await test('в выходной день у врача нет слотов', () => {
    run("DB.doctors.find(d=>d.id==='d2').workSchedule.sat = null");
    assert.equal(run("slotsForDay('2030-01-05', DB.doctors.find(d=>d.id==='d2')).length"), 0); // 2030-01-05 — суббота
  });

  await test('новая услуга сразу у врачей направления, удаление чистит привязки', () => {
    const before = run('DB.services.neurology.length');
    run("addService('neurology')");
    assert.equal(run('DB.services.neurology.length'), before + 1);
    const id = run('DB.services.neurology[DB.services.neurology.length-1].id');
    assert.equal(run(`DB.doctors.find(d=>d.id==='d2').serviceIds.includes(${JSON.stringify(id)})`), true);
    run(`DB.services.neurology.splice(DB.services.neurology.length-1,1); DB.doctors.forEach(d=>d.serviceIds=d.serviceIds.filter(s=>s!==${JSON.stringify(id)}))`);
  });

  await test('направление врача: включение добавляет услуги, выключение убирает', () => {
    run("toggleDoctorSpecialty('d2','cardiology',true)");
    assert.equal(run("DB.doctors.find(d=>d.id==='d2').serviceIds.some(s=>s.startsWith('cardiology'))"), true);
    run("toggleDoctorSpecialty('d2','cardiology',false)");
    assert.equal(run("DB.doctors.find(d=>d.id==='d2').serviceIds.some(s=>s.startsWith('cardiology'))"), false);
  });

  await test('миграция старого формата данных (specialty + пары услуг)', () => {
    run(`localStorage.setItem(LS_KEY, JSON.stringify({texts:null,
      doctors:[{id:'x',name:'Старый',role:'Врач',specialty:'uzi',experience:1,education:'',photo:null}],
      services:{uzi:[['УЗИ',100],['__group__','Группа']]},users:[],appointments:[],doctorBlocks:[],
      categories:[{id:'uzi',name:'УЗИ',short:'',icon:'uzi'}],adminPasswordHash:'h',doctorLogins:{}})); loadDB();`);
    assert.deepEqual(run('DB.doctors[0].specialties'), ['uzi']);
    assert.equal(run('DB.services.uzi[0].name'), 'УЗИ');
    assert.equal(run('DB.services.uzi[1].group'), true);
    assert.equal(run('DB.doctors[0].serviceIds.length'), 1);
    assert.ok(run('DB.doctors[0].workSchedule.mon'));
  });

  console.log(`\nпройдено: ${passed}`);
})();
