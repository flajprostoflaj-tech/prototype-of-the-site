// Собирает проект в один самодостаточный HTML-файл: node build.js
// Результат: dist/galen-clinic.html (его и публиковать/раздавать).
const fs = require('fs');
const path = require('path');

const root = __dirname;
const read = f => fs.readFileSync(path.join(root, f), 'utf8');

let html = read('index.html');

// все <link rel="stylesheet" href="css/..."> -> один <style>
const cssFiles = [...html.matchAll(/<link rel="stylesheet" href="(css\/[^"]+)">\n/g)].map(m => m[1]);
html = html.replace(/(<link rel="stylesheet" href="css\/[^"]+">\n)+/, `<style>\n${cssFiles.map(read).join('')}</style>\n`);

// все <script src="js/..."> -> один <script>
const jsFiles = [...html.matchAll(/<script src="(js\/[^"]+)"><\/script>\n/g)].map(m => m[1]);
html = html.replace(/(<script src="js\/[^"]+"><\/script>\n)+/, `<script>\n${jsFiles.map(read).join('')}</script>\n`);

fs.mkdirSync(path.join(root, 'dist'), { recursive: true });
fs.writeFileSync(path.join(root, 'dist', 'galen-clinic.html'), html);
console.log(`собрано: ${cssFiles.length} css + ${jsFiles.length} js -> dist/galen-clinic.html`);
