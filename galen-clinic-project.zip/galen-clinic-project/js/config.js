// Ключи localStorage, метка сборки (видна админу во вкладке «Сервис») и генератор id.

const LS_KEY = 'galen_clinic_db_v1';
const BUILD_TAG = 'v2026-09-29-modular';
const SESSION_KEY = 'galen_clinic_session_v1';

function uid(prefix){ return prefix+'_'+Math.random().toString(36).slice(2,9); }

