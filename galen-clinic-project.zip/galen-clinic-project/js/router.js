// Навигация без перезагрузки: go(view, params) выставляет ROUTE и вызывает render().
// render() — единственная точка отрисовки: выбирает view* по ROUTE.view. Новый экран = новая функция view + строка в render().

let ROUTE = { view:'home', params:{} };
function go(view, param){
  ROUTE = { view, params: typeof param==='object'&&param!==null ? param : {p:param} };
  window.scrollTo({top:0,behavior:'smooth'});
  closeSheet();
  render();
}

// страницы
function render(){
  renderTopbar();
  const app = document.getElementById('app');
  const v = ROUTE.view;
  if(v==='home') app.innerHTML = viewHome();
  else if(v==='services') app.innerHTML = viewServices();
  else if(v==='category') app.innerHTML = viewCategory(ROUTE.params.p);
  else if(v==='doctorServices') app.innerHTML = viewDoctorServices(ROUTE.params.doctorId, ROUTE.params.catId);
  else if(v==='booking') app.innerHTML = viewBooking(ROUTE.params.serviceId, ROUTE.params.catId);
  else if(v==='doctors') app.innerHTML = viewDoctorsFull(ROUTE.params.p);
  else if(v==='forpatients') app.innerHTML = viewForPatients(ROUTE.params.p);
  else if(v==='contacts') app.innerHTML = viewContacts();
  else if(v==='profile') app.innerHTML = viewProfile();
  else if(v==='doctorpanel') app.innerHTML = viewDoctorPanel();
  else if(v==='adminpanel') app.innerHTML = viewAdminPanel();
  else app.innerHTML = viewHome();
  afterRenderHooks();
}

