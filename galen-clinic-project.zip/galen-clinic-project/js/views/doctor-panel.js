// Кабинет врача: приёмы, рабочий график, блокировка времени.

let doctorPanelTab='schedule';
function viewDoctorPanel(){
  const user = currentUser();
  if(user && user.role==='client'){ setTimeout(()=>go('profile'),0); return ''; }
  if(user && user.role==='admin'){ setTimeout(()=>go('adminpanel'),0); return ''; }
  if(!user || user.role!=='doctor'){ setTimeout(()=>openAuth('login'),0); return `<section class="wrap" style="padding-top:60px"><div class="empty">Доступно только для врачей клиники. Войдите через «Войти» → «Я врач».</div></section>`; }
  const myAppts = DB.appointments.filter(a=>a.doctorId===user.id && a.status!=='cancelled').sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
  const myBlocks = DB.doctorBlocks.filter(b=>b.doctorId===user.id);
  const schedule = user.workSchedule || defaultWorkSchedule();
  return `
  <section class="wrap" style="padding-top:34px">
    <div class="section-head"><div><h2>Консультации и услуги</h2><p>${user.name}</p></div></div>
    <div class="dash-grid">
      <div class="dash-nav">
        <button class="${doctorPanelTab==='schedule'?'active':''}" onclick="setDocTab('schedule')">Мои приёмы</button>
        <button class="${doctorPanelTab==='workdays'?'active':''}" onclick="setDocTab('workdays')">Мой график</button>
        <button class="${doctorPanelTab==='block'?'active':''}" onclick="setDocTab('block')">Занять время</button>
      </div>
      <div>
        ${doctorPanelTab==='schedule' ? (
          myAppts.length ? myAppts.map(a=>{
            const patient = DB.users.find(u=>u.id===a.userId);
            return `<div class="appt-card"><div><div class="when">${formatDateShort(a.date)}, ${a.time}</div><div class="what">${a.serviceName} · пациент: ${patient?patient.name:'—'} · ${patient?patient.phone:''}</div></div><span class="status-badge upcoming">запись</span></div>`;
          }).join('') : `<div class="empty">Пока нет предстоящих приёмов.</div>`
        ) : doctorPanelTab==='workdays' ? `
          <div class="card">
            <p class="step-title">Рабочие дни и часы приёма</p>
            <p class="hint">Пациенты смогут записываться к вам только в отмеченные дни и часы. Изменения применяются сразу.</p>
            ${['mon','tue','wed','thu','fri','sat','sun'].map(dk=>{
              const day = schedule[dk];
              const works = !!day;
              return `<div class="workday-row">
                <label class="workday-label">
                  <input type="checkbox" ${works?'checked':''} onchange="toggleWorkDay('${dk}',this.checked)">${DAY_LABELS[dk]}
                </label>
                ${works ? `
                  <input class="input" style="max-width:120px" type="time" value="${day.start}" onchange="updateWorkDayTime('${dk}','start',this.value)">
                  <span style="color:var(--ink-soft);font-size:13px">до</span>
                  <input class="input" style="max-width:120px" type="time" value="${day.end}" onchange="updateWorkDayTime('${dk}','end',this.value)">
                ` : `<span style="font-size:13px;color:var(--ink-soft)">Выходной</span>`}
              </div>`;
            }).join('')}
          </div>` : `
          <div class="card">
            <p class="step-title">Отметить время как недоступное (отпуск, дела)</p>
            <div class="field"><label>С какой даты и времени</label><input class="input" type="datetime-local" id="blockStart"></div>
            <div class="field"><label>По какую дату и время</label><input class="input" type="datetime-local" id="blockEnd"></div>
            <button class="pill-btn" onclick="addDoctorBlock()">Заблокировать интервал</button>
            <div style="height:1px;background:var(--line);margin:18px 0"></div>
            <p class="step-title">Заблокированные периоды</p>
            ${myBlocks.length? myBlocks.map(b=>`<div class="appt-card"><div><div class="when">${new Date(b.start).toLocaleString('ru-RU')}</div><div class="what">до ${new Date(b.end).toLocaleString('ru-RU')}</div></div><button class="icon-btn" onclick="removeBlock('${b.id}')"><svg viewBox="0 0 24 24" width="16" height="16" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button></div>`).join('') : `<p style="font-size:13px;color:var(--ink-soft)">Заблокированных периодов нет. Для пациентов это время будет просто показано как «занято».</p>`}
          </div>`}
      </div>
    </div>
  </section>`;
}
function setDocTab(t){ doctorPanelTab=t; render(); }
function toggleWorkDay(dayKey, works){
  const user = currentUser();
  const d = DB.doctors.find(x=>x.id===user.id);
  d.workSchedule = d.workSchedule || defaultWorkSchedule();
  d.workSchedule[dayKey] = works ? {start:'09:00', end:'18:00'} : null;
  saveDB(); render(); toast(works ? 'День отмечен как рабочий' : 'День отмечен как выходной');
}
function updateWorkDayTime(dayKey, field, val){
  const user = currentUser();
  const d = DB.doctors.find(x=>x.id===user.id);
  if(!d.workSchedule || !d.workSchedule[dayKey]) return;
  d.workSchedule[dayKey][field] = val;
  saveDB(); toast('Часы приёма обновлены');
}
function addDoctorBlock(){
  const s = document.getElementById('blockStart').value, e = document.getElementById('blockEnd').value;
  if(!s||!e){ toast('Укажите обе даты'); return; }
  if(new Date(e)<=new Date(s)){ toast('Дата окончания должна быть позже начала'); return; }
  DB.doctorBlocks.push({ id:uid('block'), doctorId:currentUser().id, start:s, end:e });
  saveDB(); render(); toast('Время заблокировано');
}
function removeBlock(id){ DB.doctorBlocks = DB.doctorBlocks.filter(b=>b.id!==id); saveDB(); render(); }

