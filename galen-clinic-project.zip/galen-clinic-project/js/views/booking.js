// Запись на приём: выбор врача, даты, времени; расчёт слотов с учётом графика, блокировок и чужих записей.

let bookingState = { catId:null, serviceId:null, doctorId:null, date:null, time:null };

function viewBooking(serviceId, catId){
  const isNewTarget = ROUTE.params.catId!==undefined && (
    ROUTE.params.catId!==bookingState.catId ||
    ROUTE.params.serviceId!==bookingState.serviceId ||
    (ROUTE.params.doctorId||null)!==(bookingState.cameWithDoctorId||null)
  );
  if(isNewTarget){
    bookingState.catId = ROUTE.params.catId;
    bookingState.serviceId = ROUTE.params.serviceId;
    bookingState.cameWithDoctorId = ROUTE.params.doctorId || null;
    bookingState.doctorId = ROUTE.params.doctorId || null;
    bookingState.date = null;
    bookingState.time = null;
  }
  const cat = CATEGORIES.find(c=>c.id===bookingState.catId) || CATEGORIES[0];
  const service = (DB.services[cat.id]||[]).find(s=>!s.group && s.id===bookingState.serviceId) || { name:'Услуга не выбрана', price:0 };
  const catDocs = DB.doctors.filter(d=>(d.specialties||[]).includes(cat.id));
  const docs = catDocs.filter(d=>(d.serviceIds||[]).includes(service.id));
  if(!bookingState.doctorId && docs[0]) bookingState.doctorId = docs[0].id;
  const doctor = DB.doctors.find(d=>d.id===bookingState.doctorId) || docs[0];

  const days = buildNext14Days();
  if(!bookingState.date) bookingState.date = days[0].iso;

  if(!docs.length){
    return `
    <section class="wrap" style="padding-top:34px">
      <div class="section-head"><div><h2>Запись на приём</h2><p>${cat.name} · ${service.name}</p></div></div>
      <div class="empty">Пока ни один врач не оказывает эту услугу. Свяжитесь с администратором клиники по телефону, указанному в контактах.</div>
    </section>`;
  }

  return `
  <section class="wrap" style="padding-top:34px">
    <div class="section-head"><div><h2>Запись на приём</h2><p>${cat.name} · ${service.name}</p></div></div>
    <div class="booking-shell">
      <div>
        <div class="card" style="margin-bottom:18px">
          <p class="step-title">1. Выберите врача</p>
          <div class="doctor-pick">
            ${docs.map(d=>`
              <div class="doctor-pick-row ${d.id===bookingState.doctorId?'selected':''}" onclick="pickDoctor('${d.id}')">
                <span class="avatar-circ">${initials(d.name)}</span>
                <div class="info"><b>${d.name}</b><span>${d.role} · стаж ${yearsLabel(d.experience)}</span></div>
              </div>`).join('')}
          </div>
          <p class="step-title">2. Выберите дату</p>
          <div class="day-strip">
            ${days.map(d=>`<div class="day-chip ${d.iso===bookingState.date?'selected':''}" onclick="pickDate('${d.iso}')">
              <div class="dow">${d.dow}</div><div class="num">${d.num}</div></div>`).join('')}
          </div>
          <p class="step-title">3. Выберите время</p>
          <div class="slot-grid" id="slotGrid">${renderSlots(doctor, bookingState.date)}</div>
          <div class="legend">
            <span><i style="background:#fff;border:1.5px solid var(--line)"></i>свободно</span>
            <span><i style="background:var(--blue-deep)"></i>выбрано вами</span>
            <span><i style="background:#fbeceb;border:1.5px solid #f2d3d0"></i>уже занято</span>
            <span><i style="background:#fdf3e3;border:1.5px solid #f2e2bb"></i>врач недоступен</span>
          </div>
        </div>
        <div class="card">
          <p class="step-title">Сравнить свободное время у других врачей направления «${cat.name}»</p>
          ${catDocs.filter(d=>d.id!==bookingState.doctorId).map(d=>{
            const eligible = (d.serviceIds||[]).includes(service.id);
            if(eligible){
              return `<div class="doctor-pick-row" onclick="pickDoctor('${d.id}')" style="margin-bottom:10px">
                <span class="avatar-circ">${initials(d.name)}</span>
                <div class="info"><b>${d.name}</b><span>Свободно ${countFree(d,bookingState.date)} слотов на ${formatDateShort(bookingState.date)}</span></div>
              </div>`;
            }
            return `<div class="doctor-pick-row" onclick="go('doctors',{id:'${d.id}'})" style="margin-bottom:10px;opacity:.7">
                <span class="avatar-circ">${initials(d.name)}</span>
                <div class="info"><b>${d.name}</b><span>Эту услугу не оказывает — посмотреть профиль</span></div>
              </div>`;
          }).join('') || '<p style="font-size:13px;color:var(--ink-soft)">В этом направлении пока только один врач.</p>'}
        </div>
      </div>
      <div class="card summary-card">
        <p class="step-title">Ваша запись</p>
        <div class="summary-row"><span>Услуга</span><b>${service.name}</b></div>
        <div class="summary-row"><span>Врач</span><b>${doctor?doctor.name:'—'}</b></div>
        <div class="summary-row"><span>Дата</span><b>${formatDateShort(bookingState.date)}</b></div>
        <div class="summary-row"><span>Время</span><b id="summaryTime">${bookingState.time||'выберите слот'}</b></div>
        <div class="summary-row"><span>Стоимость</span><b>${(service.price||0).toLocaleString('ru-RU')} ₽</b></div>
        <button class="pill-btn" style="width:100%;justify-content:center;margin-top:14px" onclick="confirmBooking()">Подтвердить запись</button>
        ${!currentUser()?`<p class="form-note">Чтобы подтвердить запись, нужно войти в аккаунт или зарегистрироваться — это займёт минуту.</p>`:''}
      </div>
    </div>
  </section>`;
}
function pickDoctor(id){ bookingState.doctorId=id; bookingState.time=null; render(); }
function pickDate(iso){ bookingState.date=iso; bookingState.time=null; render(); }
function buildNext14Days(){
  const arr=[]; const dows=['вс','пн','вт','ср','чт','пт','сб'];
  for(let i=0;i<14;i++){
    const d = new Date(); d.setDate(d.getDate()+i);
    arr.push({ iso:d.toISOString().slice(0,10), dow:dows[d.getDay()], num:d.getDate() });
  }
  return arr;
}
function formatDateShort(iso){
  const d=new Date(iso+'T00:00:00'); const months=['янв','фев','мар','апр','мая','июн','июл','авг','сен','окт','ноя','дек'];
  return `${d.getDate()} ${months[d.getMonth()]}`;
}
function slotsForDay(iso, doctor){
  const d = new Date(iso+'T00:00:00'); const dow = d.getDay();
  const schedule = doctor && doctor.workSchedule ? doctor.workSchedule[DAY_KEYS[dow]] : null;
  if(!schedule) return [];
  const [startH0, startM0] = schedule.start.split(':').map(Number);
  const [endH0, endM0] = schedule.end.split(':').map(Number);
  const startH = startH0 + startM0/60, endH = endH0 + endM0/60;
  const slots=[];
  for(let h=startH; h<endH; h+=0.5){
    const hh = Math.floor(h), mm = (h%1)?'30':'00';
    slots.push(`${String(hh).padStart(2,'0')}:${mm}`);
  }
  return slots;
}
function seededTaken(doctorId, iso, time){
  // демо: часть слотов всегда «занята»
  let str = doctorId+iso+time, h=0;
  for(let i=0;i<str.length;i++){ h = (h*31 + str.charCodeAt(i)) >>> 0; }
  return (h % 5) === 0;
}
function isBlockedByDoctor(doctorId, iso, time){
  const dt = new Date(iso+'T'+time+':00');
  return DB.doctorBlocks.some(b=>{
    if(b.doctorId!==doctorId) return false;
    const s = new Date(b.start), e = new Date(b.end);
    return dt>=s && dt<e;
  });
}
function isBookedByAppt(doctorId, iso, time){
  return DB.appointments.some(a=>a.doctorId===doctorId && a.date===iso && a.time===time && a.status!=='cancelled');
}
function renderSlots(doctor, iso){
  if(!doctor) return '<p style="font-size:13px;color:var(--ink-soft)">Нет врачей в этом направлении.</p>';
  const slots = slotsForDay(iso, doctor);
  if(!slots.length) return '<p style="font-size:13px;color:var(--ink-soft)">У врача выходной в этот день — выберите другую дату.</p>';
  return slots.map(t=>{
    const blocked = isBlockedByDoctor(doctor.id, iso, t);
    const taken = !blocked && (seededTaken(doctor.id, iso, t) || isBookedByAppt(doctor.id, iso, t));
    const selected = bookingState.time===t && !taken && !blocked;
    let cls='slot'; if(blocked) cls+=' blocked'; else if(taken) cls+=' taken'; else if(selected) cls+=' selected';
    const click = (blocked||taken) ? '' : `onclick="pickTime('${t}')"`;
    return `<div class="${cls}" ${click}>${t}</div>`;
  }).join('');
}
function countFree(doctor, iso){
  const slots = slotsForDay(iso, doctor);
  return slots.filter(t=>!isBlockedByDoctor(doctor.id,iso,t) && !seededTaken(doctor.id,iso,t) && !isBookedByAppt(doctor.id,iso,t)).length;
}
function pickTime(t){
  bookingState.time = t;
  document.getElementById('slotGrid').innerHTML = renderSlots(DB.doctors.find(d=>d.id===bookingState.doctorId), bookingState.date);
  document.getElementById('summaryTime').textContent = t;
}
function confirmBooking(){
  if(!bookingState.time){ toast('Выберите время приёма'); return; }
  const user = currentUser();
  if(!user || user.role!=='client'){ openAuth('login'); toast('Войдите, чтобы подтвердить запись'); return; }
  const cat = CATEGORIES.find(c=>c.id===bookingState.catId);
  const service = (DB.services[cat.id]||[]).find(s=>!s.group && s.id===bookingState.serviceId);
  DB.appointments.push({
    id:uid('appt'), userId:user.id, doctorId:bookingState.doctorId,
    serviceName:service.name, price:service.price, catId:cat.id,
    date:bookingState.date, time:bookingState.time, status:'upcoming', createdAt:Date.now()
  });
  saveDB();
  toast('Запись подтверждена!');
  go('profile');
}

