// Страницы «Для пациента» и «Контакты».

let resTab = 'org';
function viewForPatients(param){
  if(param && param.p) resTab = param.p;
  else if(typeof param==='string') resTab = param;
  return `
  <section class="wrap" style="padding-top:34px">
    <div class="section-head"><div><h2>Для пациента</h2><p>Основное на виду, остальное собрано по темам, чтобы не листать лишнее</p></div></div>
    <div class="accordion">
      ${RESOURCE_TABS.map(t=>`
        <div class="acc-item ${resTab===t.id?'open':''}" id="acc-${t.id}">
          <div class="acc-head" onclick="toggleAcc('${t.id}')"><b>${t.label}</b>
            <svg viewBox="0 0 24 24" fill="none"><path d="M6 9l6 6 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
          <div class="acc-body"><div class="acc-body-inner">${t.body}</div></div>
        </div>`).join('')}
    </div>
    <div class="card" style="margin-top:18px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap">
      <div><b style="display:block;margin-bottom:4px">Лицензия клиники</b><span style="font-size:13px;color:var(--ink-soft)">Регистрационный номер Л041-01148-78/00340142</span></div>
      <button class="pill-btn ghost" onclick="toast('В демо-версии PDF-лицензия не прикреплена')">Скачать PDF</button>
    </div>
  </section>`;
}
function toggleAcc(id){
  const wasOpen = resTab===id;
  resTab = wasOpen ? null : id;
  document.querySelectorAll('.acc-item').forEach(el=>{
    const isThisOne = el.id==='acc-'+id;
    const shouldOpen = isThisOne && !wasOpen;
    el.classList.toggle('open', shouldOpen);
    const body = el.querySelector('.acc-body');
    if(!body) return;
    if(shouldOpen){ body.style.maxHeight = body.scrollHeight + 'px'; }
    else{ body.style.maxHeight = '0px'; }
  });
}

function viewContacts(){
  return `
  <section class="wrap" style="padding-top:34px">
    <div class="section-head"><div><h2>Контакты</h2><p>Мы в центре Пушкина, в 5 минутах от вокзала</p></div></div>
    <div class="loc-strip">
      <div>
        <div class="loc-item"><svg class="ic" viewBox="0 0 24 24" fill="none"><path d="M12 21s7-6.1 7-11.5A7 7 0 0 0 5 9.5C5 14.9 12 21 12 21z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><circle cx="12" cy="9.5" r="2.4" stroke="currentColor" stroke-width="1.5"/></svg>
          <div><b>Адрес</b><span>${DB.texts.address}</span></div></div>
        <div class="loc-item"><svg class="ic" viewBox="0 0 24 24" fill="none"><path d="M12 7v5l3.5 2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6"/></svg>
          <div><b>Режим работы</b><span>${DB.texts.hours}</span></div></div>
        <div class="loc-item"><svg class="ic" viewBox="0 0 24 24" fill="none"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.8 21 3 13.2 3 3.6c0-.6.4-1 1-1h3.4c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.4 0 .8-.2 1l-2.2 2.2z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>
          <div><b>Телефон</b><span>${DB.texts.phone}</span></div></div>
        <button class="pill-btn" style="margin-top:6px" onclick="go('doctors')">Записаться к врачу</button>
      </div>
      <div class="mini-map" style="height:220px"><div class="pin"></div></div>
    </div>
  </section>`;
}

