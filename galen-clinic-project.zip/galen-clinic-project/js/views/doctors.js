// Страница «Наши врачи»: слайдер карточек врачей.

let docSlideIdx = 0;
function viewDoctorsFull(param){
  if(param && param.id){
    docSlideIdx = DB.doctors.findIndex(d=>d.id===param.id);
    if(docSlideIdx<0) docSlideIdx = 0;
  }
  return `
  <section class="wrap" style="padding-top:36px">
    <div class="section-head"><div><h2>Наши врачи</h2><p>Листайте карточки стрелками, точками или свайпом</p></div></div>
    <div class="doc-slide-wrap">
      <button class="slide-arrow left" onclick="docSlide(-1)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
      <button class="slide-arrow right" onclick="docSlide(1)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M9 6l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
      <div class="doc-slide-stage" id="docSlideStage"><div class="doc-slide-track" id="docSlideTrack">
        ${DB.doctors.map(d=>`
          <div class="doc-slide"><div class="doc-big-card">
            <div class="doc-big-photo">${d.photo?`<img src="${d.photo}">`:initials(d.name)}</div>
            <div class="doc-big-info">
              <h2>${d.name}</h2>
              <p class="role">${d.role}</p>
              <dl>
                <dt>Специализация</dt><dd>${catNames(d.specialties)}</dd>
                <dt>Стаж</dt><dd>${yearsLabel(d.experience)}</dd>
              </dl>
              <p style="font-size:13.5px;color:var(--ink-soft);line-height:1.6;margin:0 0 18px">${d.education}</p>
              <p style="font-size:12px;font-weight:700;color:var(--ink-soft);text-transform:uppercase;letter-spacing:.03em;margin:0 0 8px">Выберите направление, чтобы увидеть услуги и цены</p>
              <div style="display:flex;flex-wrap:wrap;gap:8px">
                ${(d.specialties||[]).map(catId=>`<button class="pill-btn small" onclick="go('doctorServices',{doctorId:'${d.id}',catId:'${catId}'})">${catName(catId)}</button>`).join('') || '<span style="font-size:13px;color:var(--ink-soft)">Направления не указаны</span>'}
              </div>
            </div>
          </div></div>`).join('')}
      </div></div>
      <div class="dot-nav">${DB.doctors.map((d,i)=>`<button class="${i===docSlideIdx?'active':''}" onclick="docSlideTo(${i})"></button>`).join('')}</div>
    </div>
  </section>`;
}
function docSlide(dir){ docSlideTo(Math.max(0, Math.min(DB.doctors.length-1, docSlideIdx+dir))); }
function docSlideTo(i, smooth){
  docSlideIdx = i;
  const stage = document.getElementById('docSlideStage');
  if(stage) stage.scrollTo({ left: i*stage.clientWidth, behavior: smooth===false ? 'auto' : 'smooth' });
  document.querySelectorAll('.dot-nav button').forEach((b,idx)=>b.classList.toggle('active', idx===i));
}
function wireDoctorSlideScroll(){
  const stage = document.getElementById('docSlideStage');
  if(!stage || stage.dataset.wired) return;
  stage.dataset.wired = '1';
  let t=null;
  stage.addEventListener('scroll', ()=>{
    clearTimeout(t);
    t = setTimeout(()=>{
      const i = Math.round(stage.scrollLeft / stage.clientWidth);
      docSlideIdx = i;
      document.querySelectorAll('.dot-nav button').forEach((b,idx)=>b.classList.toggle('active', idx===i));
    }, 80);
  }, {passive:true});
}

