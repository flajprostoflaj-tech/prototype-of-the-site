// Главная: герой, карусели услуг и врачей, блок адреса.

function viewHome(){
  const perPage = window.innerWidth<520?1:window.innerWidth<700?2:window.innerWidth<980?3:5;
  return `
  <section class="hero">
    <div class="wrap hero-inner">
      <div>
        <h1 ${editableAttr('heroTitle')}>${DB.texts.heroTitle}</h1>
        <p class="lead" ${editableAttr('heroLead')}>${DB.texts.heroLead}</p>
        <div class="hero-cta">
          <button class="pill-btn" onclick="go('services')" style="background:#fff;color:var(--blue-deep);box-shadow:0 8px 20px -8px rgba(0,0,0,.3)">Записаться онлайн</button>
          <button class="pill-btn" onclick="go('forpatients')" style="background:rgba(0,0,0,.22);color:#fff;border:1.5px solid rgba(255,255,255,.75);box-shadow:none">Информация для пациента</button>
        </div>
        <div class="hero-facts">
          <div class="hero-fact"><svg class="ic" viewBox="0 0 24 24" fill="none"><path d="M12 7v5l3.5 2" stroke="#fff" stroke-width="1.7" stroke-linecap="round"/><circle cx="12" cy="12" r="9" stroke="#fff" stroke-width="1.6"/></svg><div><b>С 07:30 утра</b>анализы натощак до работы</div></div>
          <div class="hero-fact"><svg class="ic" viewBox="0 0 24 24" fill="none"><path d="M9 12l2 2 4-4" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="12" cy="12" r="9" stroke="#fff" stroke-width="1.6"/></svg><div><b>Лицензия Л041-01148-78</b>официальная клиника</div></div>
        </div>
      </div>
      <div class="hero-card">
        <h3>Как нас найти</h3>
        <p ${editableAttr('address')}>${DB.texts.address}</p>
        <div class="mini-map"><div class="pin"></div></div>
        <p style="margin-top:12px">${DB.texts.hours}</p>
        <button class="pill-btn small" style="width:100%;justify-content:center;margin-top:8px" onclick="go('contacts')">Маршрут и контакты</button>
      </div>
    </div>
  </section>

  <section class="wrap" style="padding-top:58px">
    <div class="section-head">
      <div><h2>Услуги</h2><p>Выберите направление — покажем все услуги и цены</p></div>
      <div class="arrow-nav">
        <button class="arrow-btn" id="svcPrev" onclick="shiftSvc(-1)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
        <button class="arrow-btn" id="svcNext" onclick="shiftSvc(1)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M9 6l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
      </div>
    </div>
    <div class="svc-track-wrap"><div class="svc-track" id="svcTrack">
      ${CATEGORIES.map(c=>`
        <div class="svc-card" onclick="go('category','${c.id}')">
          ${categoryIcon(c)}
          <h4>${c.name}</h4>
          <p>${c.short}</p>
          <div class="go">Смотреть услуги и цены <svg viewBox="0 0 24 24" fill="none"><path d="M9 6l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
        </div>`).join('')}
    </div></div>
  </section>

  <section class="wrap" style="padding-top:58px">
    <div class="section-head">
      <div><h2>Врачи</h2><p>Наведите на карточку, чтобы увидеть специализацию и стаж</p></div>
      <div class="arrow-nav">
        <button class="arrow-btn" id="docPrev" onclick="shiftDoc(-1)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M15 6l-6 6 6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
        <button class="arrow-btn" id="docNext" onclick="shiftDoc(1)"><svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M9 6l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
      </div>
    </div>
    <div class="doc-track-wrap"><div class="doc-track" id="docTrack">
      ${DB.doctors.map(d=>`
        <div class="doc-card" onclick="go('doctors',{id:'${d.id}'})">
          <div class="doc-photo">${d.photo?`<img src="${d.photo}">`:initials(d.name)}
            <div class="doc-hover-info"><b>Стаж ${yearsLabel(d.experience)}</b><span>${catNames(d.specialties)}</span></div>
          </div>
          <p class="doc-name">${d.name}</p>
          <p class="doc-role">${d.role}</p>
        </div>`).join('')}
    </div></div>
  </section>

  <section class="wrap" style="padding-top:58px">
    <div class="loc-strip">
      <div>
        <div class="loc-item"><svg class="ic" viewBox="0 0 24 24" fill="none"><path d="M12 21s7-6.1 7-11.5A7 7 0 0 0 5 9.5C5 14.9 12 21 12 21z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><circle cx="12" cy="9.5" r="2.4" stroke="currentColor" stroke-width="1.5"/></svg>
          <div><b>Адрес</b><span ${editableAttr('address')}>${DB.texts.address}. От вокзала Пушкина — 5 минут пешком, рядом парковка.</span></div></div>
        <div class="loc-item"><svg class="ic" viewBox="0 0 24 24" fill="none"><path d="M12 7v5l3.5 2" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.6"/></svg>
          <div><b>Режим работы</b><span ${editableAttr('hours')}>${DB.texts.hours}</span></div></div>
        <div class="loc-item"><svg class="ic" viewBox="0 0 24 24" fill="none"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1C10.8 21 3 13.2 3 3.6c0-.6.4-1 1-1h3.4c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.4 0 .8-.2 1l-2.2 2.2z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>
          <div><b>Телефон</b><span ${editableAttr('phone')}>${DB.texts.phone}</span></div></div>
      </div>
      <div class="mini-map" style="height:180px"><div class="pin"></div></div>
    </div>
  </section>
  `;
}
