// Панель администратора: услуги, направления, врачи, пароли врачей, служебная вкладка.
// Все правки идут через функции update*/add*/remove*/toggle* внизу файла.

let adminTab='prices';
function viewAdminPanel(){
  const user = currentUser();
  if(user && user.role==='client'){ setTimeout(()=>go('profile'),0); return ''; }
  if(user && user.role==='doctor'){ setTimeout(()=>go('doctorpanel'),0); return ''; }
  if(!user || user.role!=='admin'){ setTimeout(()=>openAuth('login'),0); return `<section class="wrap" style="padding-top:60px"><div class="empty">Доступно только администратору.</div></section>`; }
  return `
  <section class="wrap" style="padding-top:34px">
    <div class="section-head"><div><h2>Настройки сайта</h2><p>Изменения сохраняются сразу</p></div>
      <button class="pill-btn ${SESSION.editMode?'':'ghost'}" onclick="toggleEditMode()">${SESSION.editMode?'Режим редактирования включён':'Включить редактирование текстов на сайте'}</button>
    </div>
    <div class="dash-grid">
      <div class="dash-nav">
        <button class="${adminTab==='prices'?'active':''}" onclick="setAdminTab('prices')">Цены на услуги</button>
        <button class="${adminTab==='categories'?'active':''}" onclick="setAdminTab('categories')">Направления</button>
        <button class="${adminTab==='doctors'?'active':''}" onclick="setAdminTab('doctors')">Врачи и фото</button>
        <button class="${adminTab==='logins'?'active':''}" onclick="setAdminTab('logins')">Пароли для врачей</button>
        <button class="${adminTab==='service'?'active':''}" onclick="setAdminTab('service')">Сервис</button>
      </div>
      <div>${renderAdminTab()}</div>
    </div>
  </section>`;
}
function setAdminTab(t){ adminTab=t; render(); }
function toggleEditMode(){ SESSION.editMode=!SESSION.editMode; saveSession(); render(); toast(SESSION.editMode?'Кликните на подчёркнутый текст на сайте, чтобы отредактировать':'Режим редактирования выключен'); }
function renderAdminTab(){
  if(adminTab==='prices'){
    return CATEGORIES.map(cat=>`
      <div class="card" style="margin-bottom:16px">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
          <p class="step-title" style="margin:0">${cat.name}</p>
          <button class="pill-btn small" onclick="addService('${cat.id}')">+ Добавить услугу</button>
        </div>
        ${(DB.services[cat.id]||[]).map((row,idx)=> row.group ?
          `<div class="svc-group-title" style="padding-left:0">${row.label}</div>` :
          `<div class="svc-row" style="padding:10px 0">
            <div class="name"><input class="input" style="border:none;padding:0;background:transparent" value="${row.name}" onchange="updateServiceName('${cat.id}',${idx},this.value)"></div>
            <div class="price">
              <input class="input" style="width:100px;padding:6px 9px" type="number" value="${row.price}" onchange="updatePrice('${cat.id}',${idx},this.value)"> ₽
              <button class="icon-btn" title="Удалить услугу" onclick="removeService('${cat.id}',${idx})"><svg viewBox="0 0 24 24" width="15" height="15" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="var(--coral)" stroke-width="1.8" stroke-linecap="round"/></svg></button>
            </div>
          </div>`).join('') || '<p style="font-size:13px;color:var(--ink-soft)">Пока нет услуг в этом направлении.</p>'}
      </div>`).join('');
  }
  if(adminTab==='categories'){
    return `<div class="toolbar-end">
        <button class="pill-btn" onclick="addCategory()">+ Добавить направление</button>
      </div>` +
      CATEGORIES.map(cat=>`
      <div class="card" style="margin-bottom:14px">
        <div style="display:flex;gap:16px">
          ${categoryIcon(cat, 'flex:none')}
          <div style="flex:1">
            <div class="field"><label>Название направления</label><input class="input" value="${cat.name}" onchange="updateCategory('${cat.id}','name',this.value)"></div>
            <div class="field"><label>Короткое описание (на главной странице)</label><input class="input" value="${cat.short}" onchange="updateCategory('${cat.id}','short',this.value)"></div>
            <div class="field"><label>Своя картинка для квадратика услуги (ссылка на изображение)</label>
              <input class="input" placeholder="https://..." value="${cat.image||''}" onchange="updateCategory('${cat.id}','image',this.value)">
            </div>
            ${cat.image?`<button class="pill-btn ghost small" style="margin-bottom:12px" onclick="updateCategory('${cat.id}','image','')">Убрать картинку, вернуть значок</button>`:`
            <div class="field"><label>Готовый значок (используется, если своя картинка не задана)</label>
              <select class="input" onchange="updateCategory('${cat.id}','icon',this.value)">
                ${Object.keys(ICONS).map(k=>`<option value="${k}" ${k===cat.icon?'selected':''}>${k}</option>`).join('')}
              </select>
            </div>`}
            <button class="pill-btn small danger" onclick="removeCategory('${cat.id}')">Удалить направление</button>
          </div>
        </div>
      </div>`).join('');
  }
  if(adminTab==='doctors'){
    return `<div class="toolbar-end">
        <button class="pill-btn" onclick="addDoctor()">+ Добавить врача</button>
      </div>` +
      DB.doctors.map(d=>{
        const myCats = CATEGORIES.filter(c=>(d.specialties||[]).includes(c.id));
        return `
      <div class="card" style="margin-bottom:14px">
        <div style="display:flex;gap:16px">
          <div style="flex:none">
            <div class="doc-photo" style="width:80px;height:80px">${d.photo?`<img src="${d.photo}">`:initials(d.name)}</div>
          </div>
          <div style="flex:1">
            <div class="field"><label>ФИО</label><input class="input" value="${d.name}" onchange="updateDoctor('${d.id}','name',this.value)"></div>
            <div class="field"><label>Должность</label><input class="input" value="${d.role}" onchange="updateDoctor('${d.id}','role',this.value)"></div>
            <div class="field"><label>Стаж (лет)</label><input class="input" style="max-width:160px" type="number" value="${d.experience}" onchange="updateDoctor('${d.id}','experience',this.value)"></div>
            <div class="field"><label>Направления (можно выбрать несколько)</label>
              <div style="display:flex;flex-wrap:wrap;gap:8px">
                ${CATEGORIES.map(c=>`
                  <label style="display:flex;align-items:center;gap:6px;background:var(--tint);border:1px solid var(--line);border-radius:20px;padding:6px 12px 6px 8px;font-size:12.5px;font-weight:600;color:var(--blue-deep);cursor:pointer">
                    <input type="checkbox" ${((d.specialties||[]).includes(c.id))?'checked':''} onchange="toggleDoctorSpecialty('${d.id}','${c.id}',this.checked)">${c.name}
                  </label>`).join('')}
              </div>
            </div>
            <div class="field"><label>Какие услуги оказывает</label>
              ${myCats.length ? myCats.map(c=>`
                <p style="font-size:11.5px;font-weight:700;color:var(--accent);text-transform:uppercase;letter-spacing:.03em;margin:10px 0 4px">${c.name}</p>
                <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:4px">
                  ${(DB.services[c.id]||[]).filter(s=>!s.group).map(s=>`
                    <label style="display:flex;align-items:center;gap:6px;background:var(--surface);border:1px solid var(--line);border-radius:20px;padding:6px 12px 6px 8px;font-size:12.5px;font-weight:600;cursor:pointer">
                      <input type="checkbox" ${((d.serviceIds||[]).includes(s.id))?'checked':''} onchange="toggleDoctorService('${d.id}','${s.id}',this.checked)">${s.name}
                    </label>`).join('') || '<p style="font-size:12.5px;color:var(--ink-soft)">В этом направлении пока нет услуг.</p>'}
                </div>`).join('') : '<p style="font-size:12.5px;color:var(--ink-soft)">Сначала отметьте направление врача выше.</p>'}
            </div>
            <div class="field"><label>Ссылка на фото (необязательно)</label><input class="input" placeholder="https://..." value="${d.photo||''}" onchange="updateDoctor('${d.id}','photo',this.value)"></div>
            <div class="field"><label>Образование / описание</label><input class="input" value="${d.education}" onchange="updateDoctor('${d.id}','education',this.value)"></div>
            <button class="pill-btn small danger" onclick="removeDoctor('${d.id}')">Удалить врача</button>
          </div>
        </div>
      </div>`;}).join('');
  }
  if(adminTab==='logins'){
    return `<div class="card">
      <p class="step-title">Пароли для входа врачей</p>
      <p class="hint">Каждому врачу — свой пароль. Пароль хранится в виде хеша, врач входит через кнопку «Войти» → «Я врач».</p>
      ${DB.doctors.map(d=>`
        <div class="linked-row">
          <div>${d.name}</div>
          <button class="pill-btn ghost small" onclick="setDoctorPassword('${d.id}')">Задать пароль</button>
        </div>`).join('')}
    </div>`;
  }
  if(adminTab==='service'){
    const hasPwd = new Set(Object.values(DB.doctorLogins));
    return `<div class="card" style="margin-bottom:16px">
      <p class="step-title">Проверка данных</p>
      <p class="hint">Если врач появляется не в том направлении или запись ведёт себя странно — сверьтесь со списком ниже: он показывает, что на самом деле сейчас сохранено.</p>
      ${DB.doctors.map(d=>`
        <div style="padding:10px 0;border-bottom:1px solid var(--line)">
          <b style="font-size:13.5px">${d.name}</b><br>
          <span style="font-size:12px;color:var(--ink-soft)">Направления: ${(d.specialties||[]).map(catName).join(', ')||'—'}</span><br>
          <span style="font-size:12px;color:var(--ink-soft)">Оказывает услуг: ${(d.serviceIds||[]).length}</span><br>
          <span style="font-size:12px;color:${hasPwd.has(d.id)?'var(--mint)':'var(--coral)'};font-weight:600">${hasPwd.has(d.id)?'✓ Пароль задан':'✕ Пароль ещё не задан'}</span>
        </div>`).join('')}
    </div>
    <div class="card" style="margin-bottom:16px">
      <p class="step-title">Версия загруженной страницы</p>
      <p style="font-size:13px;color:var(--ink-soft);margin-top:-6px">Код: <b>${BUILD_TAG}</b>. Если после моих обновлений что-то не меняется — попробуйте закрыть эту вкладку/окно артефакта и открыть заново (или Ctrl+Shift+R), браузер мог показывать старую закэшированную версию.</p>
    </div>
    <div class="card">
      <p class="step-title">Сброс данных</p>
      <p class="hint">Если данные в браузере запутались (например, после экспериментов с чекбоксами направлений), можно вернуть сайт к заводским настройкам — все цены, врачи, записи и аккаунты в этом браузере будут удалены без возможности восстановить.</p>
      <button class="pill-btn small danger" onclick="resetAllData()">Сбросить всё до заводских настроек</button>
    </div>`;
  }
}
function resetAllData(){
  confirmDialog('Сбросить сайт до заводских настроек? Все текущие цены, врачи, записи и аккаунты в этом браузере будут удалены без возможности восстановить.', ()=>{
    try{ localStorage.removeItem(LS_KEY); localStorage.removeItem(SESSION_KEY); }catch(e){}
    location.reload();
  });
}
function updatePrice(catId, idx, val){
  DB.services[catId][idx].price = Number(val)||0;
  saveDB(); toast('Цена обновлена');
}
function updateServiceName(catId, idx, val){
  DB.services[catId][idx].name = val.trim() || 'Без названия';
  saveDB(); toast('Название обновлено');
}
function addService(catId){
  if(!DB.services[catId]) DB.services[catId] = [];
  const newId = `${catId}-svc-${uid('n')}`;
  DB.services[catId].push({ id:newId, name:'Новая услуга', price:0 });
  // новая услуга сразу у всех врачей направления, лишних админ снимет вручную
  DB.doctors.forEach(d=>{
    if((d.specialties||[]).includes(catId)){
      d.serviceIds = d.serviceIds || [];
      d.serviceIds.push(newId);
    }
  });
  saveDB(); render(); toast('Услуга добавлена — заполните название и цену, при необходимости уберите её у отдельных врачей');
}
function removeService(catId, idx){
  const row = DB.services[catId][idx];
  confirmDialog(`Удалить услугу «${row.name}»?`, ()=>{
    DB.services[catId].splice(idx,1);
    DB.doctors.forEach(d=>{ d.serviceIds = (d.serviceIds||[]).filter(sid=>sid!==row.id); });
    saveDB(); render(); toast('Услуга удалена');
  });
}
function addCategory(){
  const nc = { id:uid('cat'), name:'Новое направление', short:'Описание направления — заполните администратор.', icon:GENERIC_ICON_KEY };
  CATEGORIES.push(nc);
  DB.services[nc.id] = [];
  saveDB(); render(); toast('Направление добавлено — заполните название и добавьте услуги');
}
function updateCategory(id, field, val){
  const c = CATEGORIES.find(x=>x.id===id);
  c[field] = val;
  saveDB();
  if(field==='icon'||field==='image') render(); else toast('Сохранено');
}
function removeCategory(id){
  const c = CATEGORIES.find(x=>x.id===id);
  confirmDialog(`Удалить направление «${c?c.name:''}»? Все его услуги будут удалены, а у врачей это направление уберётся из списка специализаций.`, ()=>{
    const removedIds = (DB.services[id]||[]).filter(s=>!s.group).map(s=>s.id);
    CATEGORIES = CATEGORIES.filter(x=>x.id!==id);
    DB.categories = CATEGORIES;
    delete DB.services[id];
    DB.doctors.forEach(d=>{
      d.specialties = (d.specialties||[]).filter(s=>s!==id);
      d.serviceIds = (d.serviceIds||[]).filter(sid=>!removedIds.includes(sid));
    });
    saveDB(); render(); toast('Направление удалено');
  });
}
function updateDoctor(id, field, val){
  const d = DB.doctors.find(x=>x.id===id);
  d[field] = field==='experience' ? Number(val)||0 : val;
  saveDB();
  if(field==='photo') render(); else toast('Сохранено');
}
function toggleDoctorSpecialty(id, catId, checked){
  const d = DB.doctors.find(x=>x.id===id);
  d.specialties = d.specialties || [];
  d.serviceIds = d.serviceIds || [];
  if(checked){
    if(!d.specialties.includes(catId)) d.specialties.push(catId);
    // новое направление: сразу все его услуги, лишние можно снять
    (DB.services[catId]||[]).forEach(row=>{ if(!row.group && !d.serviceIds.includes(row.id)) d.serviceIds.push(row.id); });
  } else {
    d.specialties = d.specialties.filter(s=>s!==catId);
    const idsOfCat = (DB.services[catId]||[]).filter(s=>!s.group).map(s=>s.id);
    d.serviceIds = d.serviceIds.filter(sid=>!idsOfCat.includes(sid));
  }
  saveDB(); render(); toast('Направления врача обновлены');
}
function toggleDoctorService(id, serviceId, checked){
  const d = DB.doctors.find(x=>x.id===id);
  d.serviceIds = d.serviceIds || [];
  if(checked){ if(!d.serviceIds.includes(serviceId)) d.serviceIds.push(serviceId); }
  else{ d.serviceIds = d.serviceIds.filter(sid=>sid!==serviceId); }
  saveDB(); toast('Список услуг врача обновлён');
}
function addDoctor(){
  const nd = { id:uid('doc'), name:'Новый врач', role:'Должность не указана', specialties: CATEGORIES[0] ? [CATEGORIES[0].id] : [], serviceIds: CATEGORIES[0] ? allServiceIds([CATEGORIES[0].id]) : [], experience:0, education:'Данные уточняются администратором клиники.', photo:null, workSchedule: defaultWorkSchedule() };
  DB.doctors.push(nd); saveDB(); render(); toast('Врач добавлен — заполните карточку и задайте пароль во вкладке «Пароли»');
}
function removeDoctor(id){
  const d = DB.doctors.find(x=>x.id===id);
  confirmDialog(`Удалить врача «${d?d.name:''}»? Прошедшие записи пациентов сохранятся в истории, но записаться к этому врачу заново будет нельзя.`, ()=>{
    DB.doctors = DB.doctors.filter(x=>x.id!==id);
    Object.keys(DB.doctorLogins).forEach(h=>{ if(DB.doctorLogins[h]===id) delete DB.doctorLogins[h]; });
    saveDB(); render(); toast('Врач удалён');
  });
}
function setDoctorPassword(id){
  const d = DB.doctors.find(x=>x.id===id);
  openGenericModal(`
    <h3>Пароль для входа</h3>
    <p class="sub">Врач: ${d?d.name:''}</p>
    <div id="setPwdError"></div>
    <div class="field"><label>Новый пароль (минимум 6 символов)</label><input class="input" type="password" id="newDoctorPwd"></div>
    <button class="pill-btn" style="width:100%;justify-content:center" onclick="confirmDoctorPassword('${id}')">Сохранить пароль</button>
  `);
}
async function confirmDoctorPassword(id){
  const pwd = document.getElementById('newDoctorPwd').value;
  if(!pwd || pwd.length<6){
    document.getElementById('setPwdError').innerHTML = `<div class="form-error">Пароль должен быть не короче 6 символов</div>`;
    return;
  }
  const hash = await sha256(pwd);
  Object.keys(DB.doctorLogins).forEach(h=>{ if(DB.doctorLogins[h]===id) delete DB.doctorLogins[h]; });
  DB.doctorLogins[hash] = id;
  saveDB();
  closeGenericModal();
  toast('Пароль для врача сохранён');
}

