// Выбор направления, услуги направления, услуги конкретного врача.

function viewServices(){
  return `
  <section class="wrap" style="padding-top:34px">
    <div class="section-head"><div><h2>Выберите направление</h2><p>Дальше покажем врачей и все услуги с ценами именно в этом направлении</p></div></div>
    <div style="display:flex;flex-wrap:wrap;gap:16px">
      ${CATEGORIES.map(c=>`
        <div class="svc-card" onclick="go('category','${c.id}')">
          ${categoryIcon(c)}
          <h4>${c.name}</h4>
          <p>${c.short}</p>
          <div class="go">Смотреть услуги и цены <svg viewBox="0 0 24 24" fill="none"><path d="M9 6l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></div>
        </div>`).join('')}
    </div>
  </section>`;
}
function viewDoctorServices(doctorId, catId){
  const doctor = DB.doctors.find(d=>d.id===doctorId);
  const cat = CATEGORIES.find(c=>c.id===catId);
  if(!doctor || !cat){
    return `<section class="wrap" style="padding-top:34px"><div class="empty">Врач или направление не найдены. <button class="link-btn" onclick="go('doctors')">Вернуться к врачам</button></div></section>`;
  }
  const rows = (DB.services[cat.id]||[]).filter(r=>!r.group && (doctor.serviceIds||[]).includes(r.id));
  const otherCats = (doctor.specialties||[]).filter(id=>id!==cat.id);
  return `
  <section class="wrap" style="padding-top:34px">
    <div class="cat-hero">
      ${categoryIcon(cat)}
      <div><h1>${cat.name}</h1><p>${doctor.name} · ${doctor.role}</p></div>
    </div>
    ${otherCats.length?`<div class="cat-doctors">
      ${otherCats.map(id=>`<button class="cat-doc-chip" onclick="go('doctorServices',{doctorId:'${doctor.id}',catId:'${id}'})">${catName(id)}</button>`).join('')}
    </div>`:''}
    ${rows.length?`<div class="svc-list">
      ${rows.map(row=>`<div class="svc-row">
        <div class="name">${row.name}</div>
        <div class="price">${row.price.toLocaleString('ru-RU')} ₽ <button onclick="go('booking',{catId:'${cat.id}',serviceId:'${row.id}',doctorId:'${doctor.id}'})">Записаться</button></div>
      </div>`).join('')}
    </div>`:`<div class="empty">Этот врач пока не оказывает услуг в направлении «${cat.name}».</div>`}
    <div style="margin-top:18px"><button class="pill-btn ghost small" onclick="go('doctors',{id:'${doctor.id}'})">← Ко всем данным врача</button></div>
  </section>`;
}
function viewCategory(catId){
  const cat = CATEGORIES.find(c=>c.id===catId) || CATEGORIES[0];
  const docs = DB.doctors.filter(d=>(d.specialties||[]).includes(cat.id));
  const rows = DB.services[cat.id]||[];
  let html = `<section class="wrap">
    <div class="cat-hero">
      ${categoryIcon(cat)}
      <div><h1>${cat.name}</h1><p>${cat.short}</p></div>
    </div>
    ${docs.length?`<div class="cat-doctors">
      ${docs.map(d=>`<button class="cat-doc-chip" onclick="go('doctors',{id:'${d.id}'})"><span class="avatar-circ">${initials(d.name)}</span>${d.name.split(' ')[0]} ${d.name.split(' ')[1]||''}</button>`).join('')}
    </div>`:''}
    <div class="svc-list">`;
  rows.forEach((row)=>{
    if(row.group){
      html += `<div class="svc-group-title">${row.label}</div>`;
    } else {
      html += `<div class="svc-row">
        <div class="name">${row.name}</div>
        <div class="price">${row.price.toLocaleString('ru-RU')} ₽ <button onclick="go('booking',{catId:'${cat.id}',serviceId:'${row.id}'})">Записаться</button></div>
      </div>`;
    }
  });
  html += `</div></section>`;
  return html;
}

