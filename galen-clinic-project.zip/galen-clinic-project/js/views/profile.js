// Кабинет клиента: записи, данные, привязка соцсетей, смена пароля по коду.

let profileTab = 'appointments';
function viewProfile(){
  const user = currentUser();
  if(user && user.role==='doctor'){ setTimeout(()=>go('doctorpanel'),0); return ''; }
  if(user && user.role==='admin'){ setTimeout(()=>go('adminpanel'),0); return ''; }
  if(!user || user.role!=='client'){ setTimeout(()=>openAuth('login'),0); return `<section class="wrap" style="padding-top:60px"><div class="empty">Войдите, чтобы увидеть профиль.</div></section>`; }
  const myAppts = DB.appointments.filter(a=>a.userId===user.id).sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time));
  const today = new Date().toISOString().slice(0,10)+ (new Date().toTimeString().slice(0,5));
  return `
  <section class="wrap" style="padding-top:34px">
    <div class="section-head"><div><h2>Личный кабинет</h2><p style="color:var(--ink)">${user.name||'Пациент'}</p></div></div>
    <div class="dash-grid">
      <div class="dash-nav">
        <button class="${profileTab==='appointments'?'active':''}" onclick="setProfileTab('appointments')">Мои записи</button>
        <button class="${profileTab==='account'?'active':''}" onclick="setProfileTab('account')">Аккаунт и пароль</button>
        <button class="${profileTab==='linked'?'active':''}" onclick="setProfileTab('linked')">Связанные сервисы</button>
      </div>
      <div id="profileTabBody">${renderProfileTab(user, myAppts)}</div>
    </div>
  </section>`;
}
function setProfileTab(t){ profileTab=t; render(); }
function renderProfileTab(user, myAppts){
  if(profileTab==='appointments'){
    if(!myAppts.length) return `<div class="empty"><svg viewBox="0 0 24 24" fill="none"><path d="M8 3v3M16 3v3M4 9h16M5 6h14a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg><p>Пока нет записей — выберите услугу на главной странице.</p><button class="pill-btn" onclick="go('home')">К услугам</button></div>`;
    return myAppts.map(a=>{
      const doc = DB.doctors.find(d=>d.id===a.doctorId);
      const isPast = (a.date+a.time.replace(':','')) < (new Date().toISOString().slice(0,10)+ new Date().toTimeString().slice(0,5).replace(':',''));
      return `<div class="appt-card">
        <div><div class="when">${formatDateShort(a.date)}, ${a.time}</div><div class="what">${a.serviceName} · ${doc?doc.name:'врач'}</div></div>
        <div style="display:flex;align-items:center;gap:10px">
          <span class="status-badge ${isPast?'past':'upcoming'}">${isPast?'прошедшая':'предстоящая'}</span>
          ${!isPast?`<button class="icon-btn" title="Отменить" onclick="cancelAppt('${a.id}')"><svg viewBox="0 0 24 24" width="16" height="16" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>`:''}
        </div>
      </div>`;
    }).join('');
  }
  if(profileTab==='account'){
    return `<div class="card">
      <p class="step-title">Данные профиля</p>
      <div class="field"><label>Имя</label><input class="input" id="accName" value="${user.name||''}"></div>
      <div class="field"><label>Телефон</label><input class="input" id="accPhone" value="${user.phone||''}"></div>
      <div class="field"><label>Email</label><input class="input" id="accEmail" value="${user.email||''}" placeholder="не привязан"></div>
      <button class="pill-btn" onclick="saveAccount()">Сохранить</button>
      <div style="height:1px;background:var(--line);margin:20px 0"></div>
      <p class="step-title">Смена пароля через код на почту</p>
      <div id="pwdChangeBlock">
        <button class="pill-btn ghost" onclick="startPasswordReset()">Отправить код подтверждения</button>
      </div>
    </div>`;
  }
  if(profileTab==='linked'){
    const links = user.linked || {};
    return `<div class="card">
      <p class="step-title">Связанные аккаунты</p>
      ${['vk','max','gosuslugi'].map(k=>`
        <div class="linked-row">
          <div style="display:flex;align-items:center;gap:10px"><span class="social-ic" style="background:${socialColor(k)}">${socialLetter(k)}</span>${socialLabel(k)}</div>
          ${links[k] ? `<span class="badge-connected">Подключено</span>` : `<button class="pill-btn ghost small" onclick="toggleLink('${k}')">Подключить</button>`}
        </div>`).join('')}
      <p class="form-note" style="margin-top:14px">В этом прототипе подключение — демонстрационное. Реальная интеграция с Госуслугами/VK/MAX потребует регистрации приложения у провайдера и работы через официальный OAuth.</p>
    </div>`;
  }
}
function socialColor(k){ return k==='vk'?'#3F8AE0':k==='max'?'#0FA958':'#0B63C5'; }
function socialLetter(k){ return k==='vk'?'VK':k==='max'?'MAX':'ГУ'; }
function socialLabel(k){ return k==='vk'?'ВКонтакте':k==='max'?'MAX':'Госуслуги'; }
function toggleLink(k){
  const user = currentUser();
  const u = DB.users.find(x=>x.id===user.id);
  u.linked = u.linked || {};
  u.linked[k] = !u.linked[k];
  saveDB(); render();
  toast(u.linked[k] ? 'Аккаунт привязан' : 'Аккаунт отвязан');
}
function saveAccount(){
  const user = currentUser();
  const u = DB.users.find(x=>x.id===user.id);
  u.name = document.getElementById('accName').value.trim();
  u.phone = document.getElementById('accPhone').value.trim();
  u.email = document.getElementById('accEmail').value.trim();
  saveDB(); render(); toast('Профиль обновлён');
}
let pendingReset = null;
function startPasswordReset(){
  const user = currentUser();
  const u = DB.users.find(x=>x.id===user.id);
  if(!u.email){ toast('Сначала привяжите email'); return; }
  const code = String(Math.floor(100000+Math.random()*900000));
  pendingReset = { code, userId:u.id };
  document.getElementById('pwdChangeBlock').innerHTML = `
    <div class="form-note">Демо-режим: реального письма нет, но вот код, который в реальной системе придёт на ${u.email}: <b>${code}</b></div>
    <div class="field" style="margin-top:10px"><label>Код из письма</label><input class="input" id="resetCode"></div>
    <div class="field"><label>Новый пароль</label><input class="input" type="password" id="resetPwd"></div>
    <button class="pill-btn" onclick="finishPasswordReset()">Сменить пароль</button>`;
}
async function finishPasswordReset(){
  const code = document.getElementById('resetCode').value.trim();
  const pwd = document.getElementById('resetPwd').value;
  if(code!==pendingReset.code){ toast('Неверный код'); return; }
  if(pwd.length<6){ toast('Пароль должен быть не короче 6 символов'); return; }
  const u = DB.users.find(x=>x.id===pendingReset.userId);
  u.passwordHash = await sha256(pwd);
  saveDB();
  pendingReset=null;
  toast('Пароль изменён');
  render();
}
function cancelAppt(id){
  const a = DB.appointments.find(x=>x.id===id);
  if(a){ a.status='cancelled'; DB.appointments = DB.appointments.filter(x=>x.id!==id); saveDB(); render(); toast('Запись отменена'); }
}

