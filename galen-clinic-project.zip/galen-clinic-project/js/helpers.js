// Мелкие общие функции: инициалы, названия направлений, склонение «год/года/лет», иконка направления.

function initials(name){ return (name||'').split(' ').filter(Boolean).slice(0,2).map(w=>w[0]).join('').toUpperCase(); }
function catName(id){ const c=CATEGORIES.find(c=>c.id===id); return c?c.name:''; }
function catNames(ids){ return (ids||[]).map(catName).filter(Boolean).join(', ') || 'Направление не указано'; }
function yearsLabel(n){
  n = Math.abs(Number(n)||0);
  const mod100 = n % 100;
  const mod10 = n % 10;
  if(mod100 >= 11 && mod100 <= 14) return `${n} лет`;
  if(mod10 === 1) return `${n} год`;
  if(mod10 >= 2 && mod10 <= 4) return `${n} года`;
  return `${n} лет`;
}


// Квадратик с иконкой направления: своя картинка (если админ задал) или встроенный значок.
function categoryIcon(cat, style){
  const inner = cat.image
    ? `<img src="${cat.image}" alt="${cat.name}">`
    : `<svg viewBox="0 0 24 24">${ICONS[cat.icon]||ICONS.general}</svg>`;
  return `<div class="svc-ic"${style ? ` style="${style}"` : ''}>${inner}</div>`;
}
