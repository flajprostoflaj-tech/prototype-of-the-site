// Запуск: хуки после отрисовки, обработчик resize, первый рендер. Подключается последним.

function afterRenderHooks(){
  // пересчёт стрелок каруселей
  requestAnimationFrame(()=>{
    if(ROUTE.view==='home'){
      shiftSvc(0); shiftDoc(0);
      wireHomeSwipes();
    }
    if(ROUTE.view==='doctors'){
      docSlideTo(docSlideIdx, false);
      wireDoctorSlideScroll();
    }
    if(ROUTE.view==='forpatients'){
      const openBody = document.querySelector('.acc-item.open .acc-body');
      if(openBody) openBody.style.maxHeight = openBody.scrollHeight + 'px';
    }
  });
}
window.addEventListener('resize', ()=>{ if(ROUTE.view==='home'){ shiftSvc(0); shiftDoc(0); } });

loadDB();
loadSession();
render();
