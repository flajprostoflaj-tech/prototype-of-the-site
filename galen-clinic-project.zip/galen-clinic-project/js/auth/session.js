// Сессия (SESSION), sha256 и currentUser() — единственный источник ответа «кто сейчас вошёл».
// Внимание: у врача в БД есть своё поле role (должность), поэтому в currentUser() она кладётся в jobTitle.

let SESSION = null;
function loadSession(){
  try{
    const raw = localStorage.getItem(SESSION_KEY);
    SESSION = raw ? JSON.parse(raw) : null;
  }catch(e){ SESSION = null; }
}
function saveSession(){
  try{
    if(SESSION) localStorage.setItem(SESSION_KEY, JSON.stringify(SESSION));
    else localStorage.removeItem(SESSION_KEY);
  }catch(e){ console.error(e); }
}

async function sha256(text){
  const enc = new TextEncoder().encode(text);
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}

function currentUser(){
  if(!SESSION) return null;
  if(SESSION.role === 'admin') return { role:'admin', name:'Администратор' };
  if(SESSION.role === 'doctor'){
    const doc = DB.doctors.find(d=>d.id===SESSION.doctorId);
    if(!doc) return null;
    return { ...doc, jobTitle:doc.role, role:'doctor' };
  }
  if(SESSION.role === 'client') return { role:'client', ...DB.users.find(u=>u.id===SESSION.userId) };
  return null;
}

