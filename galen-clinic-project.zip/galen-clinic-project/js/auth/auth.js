// Окно входа/регистрации (клиент и сотрудники), выход.

let authMode = 'login';
function openAuth(mode){
  authMode = mode||'login';
  renderAuth();
  document.getElementById('authBackdrop').classList.add('open');
}
function closeAuth(){ document.getElementById('authBackdrop').classList.remove('open'); }
function switchAuthMode(m){ authMode=m; renderAuth(); }
function renderAuth(){
  const backdrop = document.getElementById('authBackdrop');
  backdrop.innerHTML = `<div class="modal">
    <div class="modal-inner-wrap">
      <button class="modal-close" onclick="closeAuth()">✕</button>
      <div class="tab-switch">
        <button class="${authMode==='login'?'active':''}" onclick="switchAuthMode('login')">Вход</button>
        <button class="${authMode==='register'?'active':''}" onclick="switchAuthMode('register')">Регистрация</button>
      </div>
      <div id="authBody"></div>
    </div>
  </div>`;
  backdrop.onclick = (e)=>{ if(e.target===backdrop) closeAuth(); };
  renderAuthBody();
}
function renderAuthBody(){
  const body = document.getElementById('authBody');
  if(authMode==='login'){
    body.innerHTML = `
      <h3>С возвращением</h3>
      <p class="sub">Войдите, чтобы управлять записями</p>
      <div class="social-row">
        <button class="social-btn" onclick="mockSocialAuth('gosuslugi')"><span class="social-ic" style="background:#0B63C5">ГУ</span>Войти через Госуслуги</button>
        <button class="social-btn" onclick="mockSocialAuth('vk')"><span class="social-ic" style="background:#3F8AE0">VK</span>Войти через VK</button>
        <button class="social-btn" onclick="mockSocialAuth('max')"><span class="social-ic" style="background:#0FA958">MAX</span>Войти через MAX</button>
      </div>
      <div class="or-line">или по паролю</div>
      <div id="authError"></div>
      <div class="field"><label>Телефон или email</label><input class="input" id="loginId" placeholder="+7 999 000-00-00"></div>
      <div class="field"><label>Пароль</label><input class="input" type="password" id="loginPwd"></div>
      <button class="pill-btn" style="width:100%;justify-content:center" onclick="doLogin()">Войти</button>
      <p style="text-align:center;margin-top:14px;font-size:12.5px;color:var(--ink-soft)">Вы врач или администратор? <button class="link-btn" onclick="switchAuthMode('staff')">Войти как сотрудник</button></p>
    `;
  } else if(authMode==='register'){
    body.innerHTML = `
      <h3>Регистрация</h3>
      <p class="sub">Понадобится телефон и пароль — так мы привяжем ваши записи к аккаунту</p>
      <div class="social-row">
        <button class="social-btn" onclick="mockSocialAuth('gosuslugi')"><span class="social-ic" style="background:#0B63C5">ГУ</span>Продолжить через Госуслуги</button>
        <button class="social-btn" onclick="mockSocialAuth('vk')"><span class="social-ic" style="background:#3F8AE0">VK</span>Продолжить через VK</button>
        <button class="social-btn" onclick="mockSocialAuth('max')"><span class="social-ic" style="background:#0FA958">MAX</span>Продолжить через MAX</button>
      </div>
      <div class="or-line">или заполните форму</div>
      <div id="authError"></div>
      <div class="field"><label>Имя и фамилия</label><input class="input" id="regName"></div>
      <div class="field"><label>Телефон</label><input class="input" id="regPhone" placeholder="+7 999 000-00-00"></div>
      <div class="field"><label>Email (необязательно)</label><input class="input" id="regEmail"></div>
      <div class="field"><label>Придумайте пароль</label><input class="input" type="password" id="regPwd"></div>
      <button class="pill-btn" style="width:100%;justify-content:center" onclick="doRegister()">Создать аккаунт</button>
    `;
  } else if(authMode==='staff'){
    body.innerHTML = `
      <h3>Вход для сотрудников</h3>
      <p class="sub">Для врачей и администратора клиники</p>
      <div id="authError"></div>
      <div class="field"><label>Пароль</label><input class="input" type="password" id="staffPwd"></div>
      <button class="pill-btn" style="width:100%;justify-content:center" onclick="doStaffLogin()">Войти</button>
      <p style="text-align:center;margin-top:14px;font-size:12.5px;color:var(--ink-soft)"><button class="link-btn" onclick="switchAuthMode('login')">Я пациент</button></p>
    `;
  }
}
function showAuthError(msg){
  document.getElementById('authError').innerHTML = `<div class="form-error">${msg}</div>`;
}
function mockSocialAuth(provider){
  showAuthError('');
  document.getElementById('authError').innerHTML = `<div class="form-note">Это демонстрационная кнопка. Реальный вход через ${socialLabel(provider)} потребует подключения официального OAuth этого провайдера на настоящем сервере — сейчас просто продолжаем как обычная регистрация.</div>`;
  setTimeout(()=>{ switchAuthMode('register'); toast('Заполните телефон и пароль, чтобы завершить вход через '+socialLabel(provider)); }, 900);
}
async function doLogin(){
  const idVal = document.getElementById('loginId').value.trim();
  const pwd = document.getElementById('loginPwd').value;
  if(!idVal||!pwd){ showAuthError('Заполните оба поля'); return; }
  const hash = await sha256(pwd);
  const u = DB.users.find(x=>(x.phone===idVal||x.email===idVal) && x.passwordHash===hash);
  if(!u){ showAuthError('Неверный логин или пароль'); return; }
  SESSION = { role:'client', userId:u.id };
  saveSession(); closeAuth(); render(); toast('Добро пожаловать, '+u.name+'!');
}
async function doRegister(){
  const name = document.getElementById('regName').value.trim();
  const phone = document.getElementById('regPhone').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const pwd = document.getElementById('regPwd').value;
  if(!name||!phone||!pwd){ showAuthError('Имя, телефон и пароль обязательны'); return; }
  if(pwd.length<6){ showAuthError('Пароль должен быть не короче 6 символов'); return; }
  if(DB.users.some(u=>u.phone===phone)){ showAuthError('Аккаунт с этим телефоном уже есть — войдите'); return; }
  const hash = await sha256(pwd);
  const u = { id:uid('user'), name, phone, email, passwordHash:hash, linked:{} };
  DB.users.push(u); saveDB();
  SESSION = { role:'client', userId:u.id };
  saveSession(); closeAuth(); render(); toast('Аккаунт создан, добро пожаловать!');
}
async function doStaffLogin(){
  const pwd = document.getElementById('staffPwd').value;
  if(!pwd){ showAuthError('Введите пароль'); return; }
  const hash = await sha256(pwd);
  if(hash === DB.adminPasswordHash){
    SESSION = { role:'admin', editMode:false };
    saveSession(); closeAuth(); toast('Вы вошли как администратор — открываю панель настроек');
    go('adminpanel');
    return;
  }
  if(DB.doctorLogins[hash]){
    SESSION = { role:'doctor', doctorId: DB.doctorLogins[hash] };
    saveSession(); closeAuth(); toast('Добро пожаловать!');
    go('doctorpanel');
    return;
  }
  showAuthError('Неверный пароль сотрудника');
}
function doLogout(){
  SESSION = null; saveSession(); go('home'); toast('Вы вышли из аккаунта');
}

