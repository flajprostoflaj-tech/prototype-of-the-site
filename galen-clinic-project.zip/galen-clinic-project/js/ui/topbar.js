// Шапка: ссылки, кнопка входа / профиль + выход, плашка администратора.

function renderTopbar(){
  const user = currentUser();
  const items = navItemsFor(user).filter(i=>i.view!=='profile'&&i.view!=='doctorpanel'&&i.view!=='adminpanel');
  document.getElementById('navLinks').innerHTML = items.map(it=>
    `<button class="nav-link ${ROUTE.view===it.view?'active':''}" onclick="go('${it.view}')">${it.label}</button>`
  ).join('');

  const authArea = document.getElementById('authArea');
  if(!user){
    authArea.innerHTML = `<button class="pill-btn" onclick="openAuth('login')">Войти</button>`;
  } else {
    const label = user.role==='admin' ? 'Админ' : user.role==='doctor' ? user.name.split(' ')[0] : (user.name||'Профиль');
    const initials = (user.name||'A').split(' ').filter(Boolean).slice(0,2).map(w=>w[0]).join('').toUpperCase();
    const target = user.role==='admin' ? 'adminpanel' : user.role==='doctor' ? 'doctorpanel' : 'profile';
    authArea.innerHTML = `<div style="display:flex;align-items:center;gap:6px">
      <button class="avatar-chip" onclick="go('${target}')" style="border:none;cursor:pointer">
      <span class="avatar-circ">${initials}</span><span>${label}</span></button>
      <button class="icon-btn" title="Выйти из аккаунта" onclick="doLogout()">
        <svg viewBox="0 0 24 24" width="17" height="17" fill="none"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
    </div>`;
  }

  document.getElementById('adminStrip').classList.toggle('hidden', !(user && user.role==='admin'));
  if(user && user.role==='admin'){
    document.getElementById('adminStripName').textContent = 'Администратор';
    document.getElementById('adminStripEditToggle').textContent = (SESSION && SESSION.editMode) ? 'Выключить редактирование текста' : 'Включить редактирование текста';
  }

  document.body.classList.toggle('admin-edit', !!(SESSION && SESSION.role==='admin' && SESSION.editMode));
}

