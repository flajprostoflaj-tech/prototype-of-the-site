// Режим «правка текстов на странице» для администратора (contenteditable + DB.texts).

function editableAttr(key){
  if(!(SESSION && SESSION.role==='admin')) return '';
  return `class="editable" contenteditable="true" data-textkey="${key}" onblur="onEditableBlur(event)"`;
}
function onEditableBlur(e){
  const key = e.target.getAttribute('data-textkey');
  if(!key) return;
  DB.texts[key] = e.target.innerText.trim();
  saveDB();
  toast('Текст сохранён');
}

