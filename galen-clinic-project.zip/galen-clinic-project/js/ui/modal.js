// Общее модальное окно и confirmDialog (вместо confirm()/prompt(), которые блокируются в песочнице).

function openGenericModal(innerHtml){
  const backdrop = document.getElementById('genericBackdrop');
  backdrop.innerHTML = `<div class="modal"><div class="modal-inner-wrap">
    <button class="modal-close" onclick="closeGenericModal()">✕</button>
    ${innerHtml}
  </div></div>`;
  backdrop.onclick = (e)=>{ if(e.target===backdrop) closeGenericModal(); };
  backdrop.classList.add('open');
}
function closeGenericModal(){ document.getElementById('genericBackdrop').classList.remove('open'); }

function confirmDialog(message, onYes){
  openGenericModal(`
    <h3>Подтвердите действие</h3>
    <p class="sub">${message}</p>
    <div style="display:flex;gap:10px;margin-top:6px">
      <button class="pill-btn ghost" style="flex:1;justify-content:center" onclick="closeGenericModal()">Отмена</button>
      <button class="pill-btn" style="flex:1;justify-content:center;background:linear-gradient(135deg,var(--coral),#c23f35)" id="confirmYesBtn">Удалить</button>
    </div>
  `);
  document.getElementById('confirmYesBtn').onclick = ()=>{ closeGenericModal(); onYes(); };
}

