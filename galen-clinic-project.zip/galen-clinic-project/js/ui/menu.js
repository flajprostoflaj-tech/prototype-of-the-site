// Мобильное меню-шторка и список пунктов по роли (navItemsFor).

function openSheet(){
  renderSheet();
  document.getElementById('sheetBackdrop').classList.add('open');
  document.getElementById('sheet').classList.add('open');
}
function closeSheet(){
  document.getElementById('sheetBackdrop').classList.remove('open');
  document.getElementById('sheet').classList.remove('open');
}
function renderSheet(){
  const items = navItemsFor(currentUser());
  document.getElementById('sheet').innerHTML = `
    <div class="sheet-handle"></div>
    ${items.map(it=>`<button class="sheet-item" onclick="go('${it.view}'${it.param?`,'${it.param}'`:''})">
        <svg class="ic" viewBox="0 0 24 24" fill="none">${it.icon}</svg>${it.label}
      </button>`).join('')}
    <div class="sheet-divider"></div>
    ${currentUser() ? `<button class="sheet-item" onclick="doLogout()"><svg class="ic" viewBox="0 0 24 24" fill="none"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>Выйти</button>`
      : `<button class="sheet-item" onclick="closeSheet();openAuth('login')"><svg class="ic" viewBox="0 0 24 24" fill="none"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg>Войти / Регистрация</button>`}
  `;
}
function navItemsFor(user){
  const base = [
    { view:'home', label:'Главная', icon:'<path d="M4 11.5 12 4l8 7.5M6 10v9a1 1 0 0 0 1 1h3v-6h4v6h3a1 1 0 0 0 1-1v-9" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>' },
    { view:'doctors', label:'Врачи', icon:'<circle cx="12" cy="8" r="3.4" stroke="currentColor" stroke-width="1.6"/><path d="M5 20c1-3.8 4-5.8 7-5.8S18 16.2 19 20" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>' },
    { view:'forpatients', label:'Для пациента', icon:'<path d="M6 4h9l3 3v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M8 10h8M8 14h5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' },
    { view:'contacts', label:'Контакты', icon:'<path d="M12 21s7-6.1 7-11.5A7 7 0 0 0 5 9.5C5 14.9 12 21 12 21z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><circle cx="12" cy="9.5" r="2.4" stroke="currentColor" stroke-width="1.5"/>' },
  ];
  if(user && user.role==='client'){
    base.push({ view:'profile', label:'Мои записи и профиль', icon:'<circle cx="12" cy="8" r="3.4" stroke="currentColor" stroke-width="1.6"/><path d="M5 20c1-3.8 4-5.8 7-5.8S18 16.2 19 20" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>' });
  }
  if(user && user.role==='doctor'){
    base.push({ view:'doctorpanel', label:'Консультации и услуги', icon:'<rect x="3" y="4" width="18" height="17" rx="2" stroke="currentColor" stroke-width="1.6"/><path d="M3 9h18M8 3v3M16 3v3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>' });
  }
  if(user && user.role==='admin'){
    base.push({ view:'adminpanel', label:'Настройки сайта', icon:'<circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.6"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.9 2.9l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.6 1.7 1.7 0 0 0-1.9.3l-.1.1A2 2 0 1 1 4 16.9l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H2.7a2 2 0 1 1 0-4H3a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.9l-.1-.1A2 2 0 1 1 7.1 4l.1.1a1.7 1.7 0 0 0 1.9.3H9.2a1.7 1.7 0 0 0 1-1.5V2.7a2 2 0 1 1 4 0V3a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.9-.3l.1-.1A2 2 0 1 1 20 7.1l-.1.1a1.7 1.7 0 0 0-.3 1.9V9.2a1.7 1.7 0 0 0 1.5 1H21.3a2 2 0 1 1 0 4H21a1.7 1.7 0 0 0-1.6 1z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/>' });
  }
  return base;
}

