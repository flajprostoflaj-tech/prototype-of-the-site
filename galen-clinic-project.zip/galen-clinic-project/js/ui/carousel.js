// Карусели на нативной прокрутке со scroll-snap; стрелки сдвигают ровно на одну карточку.

// карусели на обычной прокрутке со scroll-snap, стрелки сдвигают ровно на одну карточку
function cardStep(wrap){
  const track = wrap.firstElementChild;
  const card = track && track.firstElementChild;
  if(!card) return 0;
  const style = getComputedStyle(track);
  const gap = parseFloat(style.columnGap || style.gap || '0') || 0;
  return card.getBoundingClientRect().width + gap;
}
function scrollCarousel(wrap, dir){
  if(!wrap) return;
  wrap.scrollBy({ left: dir * cardStep(wrap), behavior:'smooth' });
}
function updateCarouselArrows(wrap, prevBtn, nextBtn){
  if(!wrap || !prevBtn || !nextBtn) return;
  const max = wrap.scrollWidth - wrap.clientWidth;
  prevBtn.disabled = wrap.scrollLeft <= 2;
  nextBtn.disabled = wrap.scrollLeft >= max - 2;
}
function shiftSvc(dir){
  const wrap = document.querySelector('.svc-track-wrap');
  if(dir!==0) scrollCarousel(wrap, dir);
  updateCarouselArrows(wrap, document.getElementById('svcPrev'), document.getElementById('svcNext'));
}
function shiftDoc(dir){
  const wrap = document.querySelector('.doc-track-wrap');
  if(dir!==0) scrollCarousel(wrap, dir);
  updateCarouselArrows(wrap, document.getElementById('docPrev'), document.getElementById('docNext'));
}
function wireHomeSwipes(){
  const svcWrap = document.querySelector('.svc-track-wrap');
  const docWrap = document.querySelector('.doc-track-wrap');
  if(svcWrap && !svcWrap.dataset.wired){
    svcWrap.dataset.wired = '1';
    svcWrap.addEventListener('scroll', ()=>updateCarouselArrows(svcWrap, document.getElementById('svcPrev'), document.getElementById('svcNext')), {passive:true});
  }
  if(docWrap && !docWrap.dataset.wired){
    docWrap.dataset.wired = '1';
    docWrap.addEventListener('scroll', ()=>updateCarouselArrows(docWrap, document.getElementById('docPrev'), document.getElementById('docNext')), {passive:true});
  }
}
