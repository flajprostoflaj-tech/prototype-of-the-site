// SVG-значки направлений. Админ может заменить значок своей картинкой (category.image).

const ICON_BACKDROP = `<circle cx="12" cy="12" r="9" fill="currentColor" fill-opacity=".14"/>`;
const ICONS = {
  gyn: ICON_BACKDROP + `
    <path d="M8.3 10.2c-1.7.6-2.8 2.1-2.8 4 0 3 2.9 5.3 6.5 5.3s6.5-2.3 6.5-5.3c0-1.9-1.1-3.4-2.8-4" stroke="currentColor" stroke-width="1.5" fill="none" stroke-linecap="round"/>
    <circle cx="7.6" cy="9.6" r="1.3" stroke="currentColor" stroke-width="1.3" fill="none"/>
    <circle cx="16.4" cy="9.6" r="1.3" stroke="currentColor" stroke-width="1.3" fill="none"/>
    <path d="M12 15v3.4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/>`,
  neuro: ICON_BACKDROP + `
    <path d="M9.8 6.2c-1.8 0-3.2 1.4-3.3 3.1-1 .5-1.7 1.6-1.7 2.8 0 1.3.8 2.4 2 2.8.1 1 .6 1.9 1.4 2.5v1.3h7.6v-1.3c.8-.6 1.3-1.5 1.4-2.5 1.2-.4 2-1.5 2-2.8 0-1.2-.7-2.3-1.7-2.8-.1-1.7-1.5-3.1-3.3-3.1-.6 0-1.1.1-1.6.4a3.2 3.2 0 0 0-2.8 0c-.5-.3-1-.4-1.6-.4z" stroke="currentColor" stroke-width="1.3" fill="none" stroke-linejoin="round"/>
    <path d="M12 8.4v9.4" stroke="currentColor" stroke-width="1.1" stroke-linecap="round"/>
    <path d="M9.6 11c.6.5 1 .5 1.6 0M12.8 11c.6.5 1 .5 1.6 0M9.6 14.2c.6.5 1 .5 1.6 0M12.8 14.2c.6.5 1 .5 1.6 0" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" fill="none"/>`,
  cardio: ICON_BACKDROP + `
    <path d="M12 17.6c-4-2.7-6.4-5.2-6.4-7.9A3.6 3.6 0 0 1 12 7.4a3.6 3.6 0 0 1 6.4 2.3c0 2.7-2.4 5.2-6.4 7.9z" stroke="currentColor" stroke-width="1.4" fill="none" stroke-linejoin="round"/>
    <path d="M6.6 11.4h2.2l1.3-3 2 5.4 1.3-3h3" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`,
  uzi: ICON_BACKDROP + `
    <rect x="9.7" y="13.5" width="3" height="6.2" rx="1.3" transform="rotate(-35 11.2 16.6)" stroke="currentColor" stroke-width="1.3" fill="none"/>
    <path d="M13.6 11.2a4 4 0 0 1 0 5.6" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" fill="none"/>
    <path d="M15.8 9a7.2 7.2 0 0 1 0 10" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" fill="none"/>`,
  proc: ICON_BACKDROP + `
    <path d="M9.4 5h5.2l-.5 4.4a2.4 2.4 0 0 1-.8 1.6c-.6.5-.9.9-.8 1.7l.9 5.6a1.8 1.8 0 0 1-1.8 2 1.8 1.8 0 0 1-1.8-2l.9-5.6c.1-.8-.2-1.2-.8-1.7a2.4 2.4 0 0 1-.8-1.6z" stroke="currentColor" stroke-width="1.3" fill="none" stroke-linejoin="round"/>
    <path d="M9.8 9.6h4.4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/>`,
  general: ICON_BACKDROP + `
    <path d="M12 8v8M8 12h8" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/>`,
};

