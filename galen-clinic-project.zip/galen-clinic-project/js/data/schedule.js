// Дни недели и рабочий график врача по умолчанию (doctor.workSchedule).

const DAY_KEYS = ['sun','mon','tue','wed','thu','fri','sat'];
const DAY_LABELS = {sun:'Воскресенье',mon:'Понедельник',tue:'Вторник',wed:'Среда',thu:'Четверг',fri:'Пятница',sat:'Суббота'};
function defaultWorkSchedule(){
  return {
    mon:{start:'07:30',end:'19:30'}, tue:{start:'07:30',end:'19:30'}, wed:{start:'07:30',end:'19:30'},
    thu:{start:'07:30',end:'19:30'}, fri:{start:'07:30',end:'19:30'},
    sat:{start:'09:00',end:'15:00'}, sun:{start:'09:00',end:'15:00'},
  };
}

