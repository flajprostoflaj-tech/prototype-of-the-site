// «База данных» в localStorage: defaultDB(), loadDB() (с миграцией старых форматов), saveDB().
// Любое изменение данных = поменять DB и вызвать saveDB(), затем render().

function defaultDB(){
  const services = buildDefaultServices();
  const doctors = JSON.parse(JSON.stringify(DEFAULT_DOCTORS));
  doctors.forEach(d=>{
    const ids = [];
    (d.specialties||[]).forEach(catId=>{ (services[catId]||[]).forEach(row=>{ if(!row.group) ids.push(row.id); }); });
    d.serviceIds = ids;
    d.workSchedule = defaultWorkSchedule();
  });
  return {
    categories: JSON.parse(JSON.stringify(CATEGORIES)),
    services,
    doctors,
    users: [],
    appointments: [],
    doctorBlocks: [], // {id, doctorId, start:'YYYY-MM-DDTHH:mm', end:'YYYY-MM-DDTHH:mm'}
    texts: {
      heroTitle: 'Точность диагностики. Забота о пациенте. Результат, которому можно доверять.',
      heroLead: 'Лечебно-диагностический центр в центре Пушкина. Принимаем взрослых. Работаем с 07:30 утра — чтобы вы успели сдать анализы натощак до работы или учёбы.',
      address: 'Пушкин, Конюшенная ул., 38/37, литер А',
      hours: 'ПН–ПТ: 07:30 – 19:30 · СБ, ВС: 09:00 – 15:00',
      phone: '+7 (812) 466-25-45',
    },
    adminPasswordHash: '9bbf45a1fa1ba0b9d8bd758f90288c04b5cf2b326e3012b2f8e96f8a5ee1eb57',
    doctorLogins: {}, // passwordHash -> doctorId
  };
}

let DB = null;
function loadDB(){
  try{
    const raw = localStorage.getItem(LS_KEY);
    if(raw){ DB = JSON.parse(raw); }
    else { DB = defaultDB(); saveDB(); }
    if(!DB.texts) DB.texts = defaultDB().texts;
    if(!DB.doctorLogins) DB.doctorLogins = {};
    if(!DB.categories || !DB.categories.length) DB.categories = JSON.parse(JSON.stringify(CATEGORIES));
    // старые данные: одно направление -> список
    DB.doctors.forEach(d=>{
      if(!d.specialties){ d.specialties = d.specialty ? [d.specialty] : []; }
      delete d.specialty;
    });
    // старые данные: услуги в виде пар
    Object.keys(DB.services||{}).forEach(catId=>{
      DB.services[catId] = (DB.services[catId]||[]).map((row,i)=>{
        if(Array.isArray(row)){
          return row[0]==='__group__' ? { group:true, label:row[1] } : { id:`${catId}-svc-${i}-${uid('m')}`, name:row[0], price:row[1] };
        }
        return row;
      });
    });
    // CATEGORIES указывает на тот же список, что правит админ
    CATEGORIES = DB.categories;
    // у старых врачей по умолчанию все услуги их направлений
    DB.doctors.forEach(d=>{
      if(!d.serviceIds) d.serviceIds = allServiceIds(d.specialties);
      if(!d.workSchedule) d.workSchedule = defaultWorkSchedule();
    });
  }catch(e){
    console.error('Storage error, using in-memory defaults', e);
    DB = defaultDB();
    CATEGORIES = DB.categories;
  }
}
function saveDB(){
  try{ localStorage.setItem(LS_KEY, JSON.stringify(DB)); }
  catch(e){ console.error('Could not save storage', e); }
}

